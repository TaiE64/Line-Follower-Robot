#ifndef ACCELEROMETER_H
#define ACCELEROMETER_H

#define ISM330DHCX_ACC_SENSITIVITY_FS_2G   0.061f

#include "mbed.h"

class Accelerometer {
private:
    I2C i2c;
    uint8_t ADDRESS_;
    void writeRegister(uint8_t address, uint8_t reg, uint8_t data);
    uint8_t readRegister(uint8_t address, uint8_t reg);

public:
    Accelerometer(PinName sda, PinName scl);  

    void init(uint8_t address, uint8_t reg, uint8_t mode); // initialisation function
    void readRawAccelerations(int16_t &x_ism, int16_t &y_ism, int16_t &z_ism);  // values BEFORE scaling with sensitivity
    void readAccelerations(int32_t &x_acc, int32_t &y_acc, int32_t &z_acc);     // values AFTER scaling with sensitivity
};

#endif