
// int main()
// {
//   Enable_Motor_Shield.write(1); // enable motor shield
//   motor1_PWM.period_us(50); // set PWM pulse period of 50 us
//   motor2_PWM.period_us(50);
//   while (user_btn == 0)
//   {
//   motor1_PWM.write(abs(motor1_voltage));
// //   motor2_PWM.write(abs(motor1_voltage));
//   thread_sleep_for(1); // sleep very briefly
//   }
//   motor1_PWM.write(0); // stop the motor
//   motor2_PWM.write(0);
// }

#include "mbed.h"
#include <UCL_encoder.h>

//MOTOR
PwmOut motor1_PWM(D5); // motor PWM
DigitalOut motor1_dir(D6); // motor direction
PwmOut motor2_PWM(D4); // motor PWM_2
DigitalOut motor2_dir(D7); // motor direction_7
DigitalOut Enable_Motor_Shield(A0); // pin for enable (1) or disable (0)
float motor1_voltage = 0.8; // motor voltage, between 0.0f and 1.0f
DigitalOut led1(LED1);
DigitalIn user_btn(BUTTON1);

//SENSOR
DigitalIn irSensorM(D13); // Assuming the IR sensor is connected to pin D13
DigitalIn irSensorR(D11);
DigitalIn irSensorL(D10); 

// Threshold value to differentiate between black line and white surface
const int threshold = 0.98; // Adjust this value based on calibration

int main() {
    Enable_Motor_Shield.write(1); // enable motor shield
     motor1_PWM.period_us(50); // set PWM pulse period of 50 us
     motor2_PWM.period_us(50);
        float sensorValueM =0;
        float sensorValueR =0;
        float sensorValueL =0;

    while(user_btn == 0) {
        // Read sensor value
        sensorValueM = irSensorM.read(); // Read analog value (assuming your IR sensor returns analog value)
        sensorValueR = irSensorR.read();
        sensorValueL = irSensorL.read();
        // Check if the sensor is over a black line or a white surface
        if(sensorValueM > threshold ) 
        {
            motor1_PWM.write(abs(motor1_voltage));
            motor2_PWM.write(abs(motor1_voltage));
            printf("Black Line Detected(M)\n");
        } 
        else 
        {
            printf("White Surface(M)\n");
        }
     

        if (sensorValueL > threshold)
        {
            motor1_PWM.write(abs(motor1_voltage));
            motor2_PWM.write(0);
        }
        else if (sensorValueR > threshold)
        {
            motor2_PWM.write(abs(motor1_voltage));
            motor1_PWM.write(0);
        }
        
        else
        {
            motor1_PWM.write(abs(motor1_voltage));
            motor2_PWM.write(abs(motor1_voltage));
        }



        thread_sleep_for(300);

    }
    motor1_PWM.write(0);
    motor2_PWM.write(0);

    return 0;
}

